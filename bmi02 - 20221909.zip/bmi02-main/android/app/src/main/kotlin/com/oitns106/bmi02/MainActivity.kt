package com.oitns106.bmi02

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
